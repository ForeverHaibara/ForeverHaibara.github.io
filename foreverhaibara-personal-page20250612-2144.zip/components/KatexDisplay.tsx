
import React, { useEffect, useRef } from 'react';

// Define more specific types for KaTeX
interface KatexOptions {
  displayMode?: boolean;
  throwOnError?: boolean;
  // Add other KaTeX options if needed, e.g., macros, colorIsTextColor, etc.
  errorColor?: string;
  macros?: object;
  maxSize?: number;
  maxExpand?: number;
  strict?: boolean | string | Function;
  trust?: boolean | Function;
  output?: "html" | "mathml" | "htmlAndMathml";
}

interface Katex {
  render(expression: string, element: HTMLElement, options?: KatexOptions): void;
  renderToString(expression: string, options?: KatexOptions): string;
  // Potentially other methods/properties if used, e.g., __parse for testing
}

// Extend the Window interface
declare global {
  interface Window {
    katex?: Katex; // Make it optional in case it fails to load
  }
}

interface KatexDisplayProps {
  latex: string;
  className?: string;
  isBlockMode?: boolean; // KaTeX displayMode
}

const KatexDisplay: React.FC<KatexDisplayProps> = ({ latex, className = '', isBlockMode = true }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current && window.katex) {
      try {
        window.katex.render(latex, containerRef.current, {
          throwOnError: false,
          displayMode: isBlockMode,
        });
      } catch (error) {
        console.error('KaTeX rendering error:', error);
        containerRef.current.textContent = 'Error rendering LaTeX.';
      }
    } else if (!window.katex) {
        console.warn('KaTeX library not found or not loaded yet.');
         if(containerRef.current) containerRef.current.textContent = 'KaTeX library not loaded.';
    }
  }, [latex, isBlockMode]);

  return <div ref={containerRef} className={`katex-render-container ${className}`} aria-live="polite">{latex}</div>;
};

export default KatexDisplay;
