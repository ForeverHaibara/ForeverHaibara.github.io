
# ForeverHaibara Personal Website

This is the source code for the personal website of ForeverHaibara, built with React, TypeScript, Tailwind CSS, and featuring an interactive demo for the 'triples' inequality proof library using a Gradio backend.

## Features

-   Clean, modern, responsive design with a blue/white color scheme.
-   Multiple pages (Home, About, Triples Solver).
-   **Triples Solver**: An interface to input mathematical expressions and get non-negativity proofs via the Sum of Squares method by calling a Gradio backend.

## Tech Stack

-   **Frontend**: React 18, TypeScript, Vite (recommended for setup), Tailwind CSS
-   **Routing**: React Router (HashRouter for GitHub Pages compatibility)
-   **Gradio Interaction**: `@gradio/client`

## Project Setup and Running Locally

While the generated code provides the core React application files, you'll need a development environment to run and build it. Vite is recommended.

**1. Prerequisites:**
   - Node.js (v18.x or newer recommended)
   - npm or yarn

**2. Initialize a Vite Project (if starting from scratch):**
   ```bash
   npm create vite@latest my-personal-website -- --template react-ts
   cd my-personal-website
   npm install
   ```

**3. Integrate Generated Files:**
   - Copy all the generated `.tsx`, `.ts`, `.html`, and `.json` files into the `src` directory of your Vite project (or the project root for `index.html`, `metadata.json`, and `README.md`).
   - For `index.html`, ensure it's at the root of your project and Vite is configured to use it (default for Vite).
   - Your `src` directory should contain `App.tsx`, `index.tsx`, and the `components/`, `pages/`, `services/`, `types.ts`, `constants.ts` files/folders.
   - You might need to adjust paths in `index.html` for `src="/index.tsx"` if your Vite setup places `index.tsx` in `src/`. Usually, Vite handles this if `index.html` is in the root and `index.tsx` is in `src/`. The provided `index.html` uses `src="/index.tsx"`, assuming `index.tsx` is served from the root. If `index.tsx` is in `src/`, this should be `src="/src/index.tsx"` or configure Vite's `root` option. For a standard Vite `react-ts` template, move `index.tsx` to `src/main.tsx` and update `index.html` script tag to `src="/src/main.tsx"`. The provided code uses `index.tsx` at the root.

**4. Install Dependencies:**
   Make sure you have the necessary dependencies installed:
   ```bash
   npm install react react-dom react-router-dom @gradio/client
   # For development
   npm install -D typescript @types/react @types/react-dom @vitejs/plugin-react tailwindcss postcss autoprefixer
   ```

**5. Configure Tailwind CSS with Vite:**
   - Create `tailwind.config.js` and `postcss.config.js`:
     ```bash
     npx tailwindcss init -p
     ```
   - Configure `tailwind.config.js`:
     ```javascript
     /** @type {import('tailwindcss').Config} */
     export default {
       content: [
         "./index.html",
         "./*.{js,ts,jsx,tsx}",
         "./src/**/*.{js,ts,jsx,tsx}",
         "./components/**/*.{js,ts,jsx,tsx}",
         "./pages/**/*.{js,ts,jsx,tsx}",
       ],
       theme: {
         extend: {
            fontFamily: {
              sans: ['Inter', 'sans-serif'], // Match font in index.html
            },
         },
       },
       plugins: [],
     }
     ```
   - Create a `src/index.css` (or `style.css`) file and add Tailwind directives:
     ```css
     @tailwind base;
     @tailwind components;
     @tailwind utilities;
     ```
   - Import this CSS file in your main entry point (e.g., `src/index.tsx` or `src/main.tsx`):
     ```typescript
     import './index.css'; // Or your CSS file path
     ```
   - **Note:** The generated `index.html` uses the Tailwind CDN. If you set up Tailwind with PostCSS, you can remove the CDN script tag. For simplicity, the CDN method is provided. If using the build process, the PostCSS method is generally preferred.

**6. Configure Gradio Backend URL:**
   - Open `constants.ts`.
   - Update `GRADIO_TRIPLES_URL` to point to your deployed Gradio application.
     ```typescript
     export const GRADIO_TRIPLES_URL = 'YOUR_GRADIO_APP_URL'; // e.g., 'https://username-spacename.hf.space/' or 'http://localhost:7860/'
     ```
   - Ensure `GRADIO_SUM_OF_SQUARES_ENDPOINT` matches the API endpoint name in your Gradio app (default in the example is `/sum_of_squares`).

**7. Start the Development Server:**
   ```bash
   npm run dev
   ```
   This will typically start the app on `http://localhost:5173`.

## Triples Gradio Backend

The "Triples Solver" page communicates with a Gradio backend. You need to have this backend running and accessible at the URL specified in `constants.ts`.

**Example Gradio App (`app.py`):**
```python
import gradio as gr

# Placeholder for your actual triples library logic
# from your_triples_library import prove_non_negativity

def sum_of_squares_proof(expr_str: str):
    """
    Attempts to prove the non-negativity of the expression.
    Replace this with your actual proof logic.
    """
    print(f"Received expression: {expr_str}")
    if not expr_str.strip():
        return "Error: Please enter a mathematical expression."
    try:
        # result = prove_non_negativity(expr_str) # Your actual library call
        # Dummy logic for demonstration:
        if "x^2" in expr_str and "y^2" in expr_str and "-2*x*y" in expr_str :
             proof_details = f"Expression: {expr_str}\n"
             proof_details += "Proof by SOS:\n"
             proof_details += f"{expr_str} = (x - y)^2 >= 0.\n"
             proof_details += "The expression is non-negative."
             return proof_details
        elif "error_test" in expr_str:
            raise ValueError("This is a simulated processing error.")
        else:
            return f"Could not automatically prove non-negativity for '{expr_str}' with the current simple demo logic. More complex proof required or expression might not be non-negative by SOS."

    except Exception as e:
        return f"Error processing expression '{expr_str}': {str(e)}"

# Create the Gradio interface
# The function name (`sum_of_squares_proof`) itself does not define the endpoint for `client.predict`.
# The endpoint is implicitly `/api/predict/` if not specified or can be named.
# To match `client.predict("/sum_of_squares", ...)` you might need to structure your Gradio app
# with multiple named endpoints or use a framework on top of Gradio if `Client.predict` specifically needs that path.
# However, often `@gradio/client` `predict`'s first argument is the "api_name" if the app has multiple endpoints.
# If your app has one function, `predict(0, ...)` or `predict(api_name="/predict", ...)` might be used.
# The user's example `client.predict("/sum_of_squares", ...)` suggests the Gradio app is configured to expose this named endpoint.
# A common way Gradio exposes functions is via an index or an explicit api_name.
# If `GRADIO_SUM_OF_SQUARES_ENDPOINT = '/predict'` (default for single function apps via API), it might work.
# Or, if your Gradio app is structured with `gr.Blocks()` and multiple `gr.Button()` elements tied to Python functions,
# each can have an `api_name`.

# For a simple interface, Gradio typically exposes a default predict endpoint.
# The endpoint `/sum_of_squares` needs to be explicitly available or the client call adjusted.
# If using a single default function, the endpoint in `constants.ts` might need to be `/api/predict/` or simply `/predict`.
# Check Gradio docs for how named endpoints are exposed to the JS client.

iface = gr.Interface(
    fn=sum_of_squares_proof,
    inputs=gr.Textbox(lines=3, placeholder="Enter mathematical expression (e.g., x^2 - 2*x*y + y^2)", label="Expression (expr)"),
    outputs=gr.Textbox(label="Proof Result", lines=10),
    title="Triples Inequality Prover Backend",
    description="Backend service for proving non-negativity of mathematical expressions using SOS method.",
    allow_flagging="never"
)

# To make it accessible for the JS client's `predict("/sum_of_squares", ...)` call,
# you might need to launch with specific API naming if Gradio supports it directly,
# or wrap it in a framework like FastAPI that exposes Gradio apps with custom routes.
# For simplicity, assuming the Gradio server (e.g. via `iface.launch()`) implicitly handles
# the endpoint path `/sum_of_squares` if the function is the primary one, or if it's explicitly named.
# If `client.predict("/sum_of_squares", ...)` doesn't work, try changing `GRADIO_SUM_OF_SQUARES_ENDPOINT`
# to `/predict` or check the Gradio JS client documentation for how it maps to functions.

if __name__ == "__main__":
    # share=True creates a public link if you want to test from a non-local frontend
    # server_name="0.0.0.0" makes it accessible on your network
    iface.launch(server_name="0.0.0.0", server_port=7860) # Default URL: http://localhost:7860
```
Run this Python script to start your Gradio backend.

## Building for Production

```bash
npm run build
```
This command will create a `dist` folder (or similar, depending on your Vite configuration) with the optimized static assets for your website.

## Deploying to GitHub Pages

1.  **Repository Setup:**
    -   Ensure your project is a GitHub repository.
    -   Push your code to the repository.

2.  **Configure `vite.config.js` (or equivalent for your build tool):**
    -   If your GitHub Pages site will be served from a subdirectory (e.g., `https://YourUsername.github.io/YourRepositoryName/`), you need to set the `base` path in your `vite.config.js`:
        ```javascript
        // vite.config.js
        import { defineConfig } from 'vite';
        import react from '@vitejs/plugin-react';

        export default defineConfig({
          plugins: [react()],
          base: '/YourRepositoryName/', // Replace YourRepositoryName with your actual repository name
        });
        ```
    -   If deploying to `https://YourUsername.github.io/` (i.e., a repository named `YourUsername.github.io`), the `base` should be `/`.

3.  **Build the Project:**
    ```bash
    npm run build
    ```

4.  **Deploy:**
    There are several ways to deploy to GitHub Pages:
    -   **`gh-pages` branch:** Commit the contents of your `dist` folder to a `gh-pages` branch. Configure GitHub Pages to serve from this branch.
    -   **GitHub Actions:** Set up a GitHub Action workflow to automatically build and deploy your site to GitHub Pages on pushes to your main branch. This is the recommended method.

    **Example GitHub Action Workflow (`.github/workflows/deploy.yml`):**
    ```yaml
    name: Deploy to GitHub Pages

    on:
      push:
        branches:
          - main # Or your default branch
      workflow_dispatch:

    permissions:
      contents: read
      pages: write
      id-token: write

    jobs:
      build:
        runs-on: ubuntu-latest
        steps:
          - name: Checkout repository
            uses: actions/checkout@v4

          - name: Setup Node.js
            uses: actions/setup-node@v4
            with:
              node-version: '18' # Or your preferred Node.js version
              cache: 'npm'

          - name: Install dependencies
            run: npm install

          - name: Build project
            run: npm run build # Ensure your base path is correctly set in vite.config.js

          - name: Upload GitHub Pages artifact
            uses: actions/upload-pages-artifact@v3
            with:
              path: ./dist # Or your build output directory

      deploy:
        needs: build
        runs-on: ubuntu-latest
        environment:
          name: github-pages
          url: ${{ steps.deployment.outputs.page_url }}
        steps:
          - name: Deploy to GitHub Pages
            id: deployment
            uses: actions/deploy-pages@v4
    ```

5.  **Configure GitHub Pages Settings:**
    -   In your GitHub repository, go to `Settings` > `Pages`.
    -   Under `Build and deployment`, select `GitHub Actions` as the source.

Your website should then be live at the GitHub Pages URL. Remember that `HashRouter` is used, so URLs will contain a `#` (e.g., `https://YourUsername.github.io/YourRepositoryName/#/triples`).
This is because GitHub Pages is primarily for static sites and doesn't handle arbitrary URL paths without server-side configuration, which `HashRouter` bypasses by using the URL hash.

---

This project provides a solid foundation for your personal website. Feel free to expand upon it by adding more pages, features, and styling. Good luck!
