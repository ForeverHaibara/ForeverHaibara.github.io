import React, { useState, useCallback } from 'react';
import { GRADIO_TRIPLES_URL } from '../../constants.ts'; // GRADIO_SUM_OF_SQUARES_ENDPOINT is used in service
import { callTriplesGradioApi } from '../../services/triplesService.ts';
import type { GradioServiceCallResult, TriplesOutput } from '../../types.ts';
import LoadingSpinner from '../../components/LoadingSpinner.tsx';
import AlertMessage from '../../components/AlertMessage.tsx';
import KatexDisplay from '../../components/KatexDisplay.tsx';

type TabKey = 'solution' | 'latex' | 'latex_aligned';

const TriplesSolverPage: React.FC = () => {
  const [expression, setExpression] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [apiResult, setApiResult] = useState<GradioServiceCallResult | null>(null);
  const [error, setError] = useState<string | null>(null); // For form validation or client-side issues
  const [activeTab, setActiveTab] = useState<TabKey>('solution');
  const [copyStatus, setCopyStatus] = useState<Record<TabKey, string>>({
    solution: 'Copy',
    latex: 'Copy',
    latex_aligned: 'Copy',
  });

  const handleSubmit = useCallback(async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!expression.trim()) {
      setError('Please enter a mathematical expression.');
      setApiResult(null);
      return;
    }

    setIsLoading(true);
    setError(null);
    setApiResult(null);
    // Reset copy statuses
    setCopyStatus({ solution: 'Copy', latex: 'Copy', latex_aligned: 'Copy' });


    try {
      const result = await callTriplesGradioApi(expression);
      setApiResult(result);
      if (!result.apiSuccess) {
        setError(result.errorMessage || 'An unknown API error occurred.');
      } else if (result.data && !result.data.success) {
        // Proof failed, display error from proof data
        // This could be shown in AlertMessage or a specific result area
      }
    } catch (err: any) { // Should be caught by callTriplesGradioApi, but as a fallback
      console.error('Gradio API call failed unexpectedly:', err);
      setError(err.message || 'Failed to connect to the Triples proof service.');
      setApiResult({ apiSuccess: false, errorMessage: err.message || 'Client-side error during API call.' });
    } finally {
      setIsLoading(false);
    }
  }, [expression]);

  const handleClearError = useCallback(() => {
    setError(null);
    if(apiResult && !apiResult.apiSuccess) {
      setApiResult(null); // Clear API error message as well if user dismisses
    }
  }, [apiResult]);

  const handleCopy = useCallback((textToCopy: string, tabKey: TabKey) => {
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopyStatus(prev => ({ ...prev, [tabKey]: 'Copied!' }));
      setTimeout(() => {
        setCopyStatus(prev => ({ ...prev, [tabKey]: 'Copy' }));
      }, 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
      setCopyStatus(prev => ({ ...prev, [tabKey]: 'Failed' }));
       setTimeout(() => {
        setCopyStatus(prev => ({ ...prev, [tabKey]: 'Copy' }));
      }, 2000);
    });
  }, []);

  const proofData = apiResult?.apiSuccess ? apiResult.data : null;

  return (
    <div className="bg-white p-6 sm:p-8 rounded-xl shadow-xl max-w-4xl mx-auto">
      <header className="mb-8 text-center">
        <h1 className="text-3xl sm:text-4xl font-bold text-blue-700">Triples Inequality Prover</h1>
        <p className="text-slate-600 mt-2 text-sm sm:text-base">
          Enter a mathematical expression to attempt a proof of its non-negativity using the Sum of Squares (SOS) method.
          This tool connects to a Gradio backend at <code className="bg-slate-200 p-1 rounded text-sm">{GRADIO_TRIPLES_URL}</code>.
        </p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="expression" className="block text-sm font-medium text-slate-700 mb-1">
            Mathematical Expression
          </label>
          <textarea
            id="expression"
            value={expression}
            onChange={(e) => setExpression(e.target.value)}
            placeholder="e.g., x^2 - 2*x*y + y^2 or a*b*(a-b)^2 + b*c*(b-c)^2 + c*a*(c-a)^2"
            rows={4}
            className="w-full p-3 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 transition-colors text-slate-800"
            disabled={isLoading}
            aria-label="Mathematical Expression Input"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <LoadingSpinner size="sm" />
              <span className="ml-2">Proving...</span>
            </>
          ) : (
            'Prove Non-negativity'
          )}
        </button>
      </form>

      {error && (
        <div className="mt-6">
          <AlertMessage type="error" message={error} onClose={handleClearError} />
        </div>
      )}
      
      {/* Display API call errors if not a form error */}
      {!error && apiResult && !apiResult.apiSuccess && (
         <div className="mt-6">
          <AlertMessage type="error" message={apiResult.errorMessage || "An unknown API error occurred."} onClose={() => setApiResult(null)} />
        </div>
      )}

      {/* Display proof failure message */}
      {proofData && !proofData.success && proofData.error && (
        <div className="mt-6">
          <AlertMessage type="warning" message={`Proof attempt failed: ${proofData.error}`} onClose={() => setApiResult(null)} />
        </div>
      )}
      
      {/* Successful proof display */}
      {proofData && proofData.success && (
        <div className="mt-8 pt-6 border-t border-slate-200 space-y-6">
          <div>
            <h2 className="text-2xl font-semibold text-slate-700 mb-3 text-center">Formatted Proof (KaTeX)</h2>
            <div className="bg-slate-50 p-4 rounded-md shadow-inner overflow-x-auto text-center">
              <KatexDisplay latex={proofData.latex_aligned} className="text-lg" />
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-semibold text-slate-700 mb-4 text-center">Result Details</h2>
            <div className="border border-slate-200 rounded-lg shadow-sm">
              <div className="flex border-b border-slate-200">
                {(['solution', 'latex', 'latex_aligned'] as TabKey[]).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-2 px-4 text-sm font-medium transition-colors focus:outline-none
                      ${activeTab === tab 
                        ? 'bg-blue-500 text-white border-b-2 border-blue-700' 
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
                      }
                      ${tab === 'solution' ? 'rounded-tl-md' : ''}
                      ${tab === 'latex_aligned' ? 'rounded-tr-md' : ''}
                    `}
                  >
                    {tab.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </button>
                ))}
              </div>
              <div className="p-4 bg-slate-50 rounded-b-lg relative">
                <button
                  onClick={() => handleCopy(proofData[activeTab], activeTab)}
                  className="absolute top-3 right-3 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium py-1 px-2 rounded transition-colors"
                  aria-label={`Copy ${activeTab.replace('_', ' ')}`}
                >
                  {copyStatus[activeTab]}
                </button>
                <pre className="whitespace-pre-wrap break-all text-slate-800 text-sm leading-relaxed max-h-60 overflow-y-auto pr-16">
                  {proofData[activeTab]}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TriplesSolverPage;
